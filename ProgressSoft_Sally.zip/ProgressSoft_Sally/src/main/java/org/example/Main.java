package org.example;

import java.util.Scanner;

import static org.example.functions.*;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Prompt user for the number of deals to enter
        System.out.print("Enter the number of deals you want to enter: ");
        int numberOfDeals = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Create an array to store Deal objects
        Deal[] deals = new Deal[numberOfDeals];

        // Loop to gather details for each deal
        for (int i = 0; i < numberOfDeals; i++) {
            System.out.println("Enter details for Deal #" + (i + 1));
            deals[i] = createDealFromUserInput();
        }

        // Loop to save each valid deal to the database
        for (Deal deal : deals) {
            // Check if the deal is valid, unique, and not null before saving to the database
            if (isUniqueIdUnique(deal.uniqueId) && deal != null && isValidDeal(deal)) {
                saveDealToDatabase(deal);
            }
        }
    }
}
