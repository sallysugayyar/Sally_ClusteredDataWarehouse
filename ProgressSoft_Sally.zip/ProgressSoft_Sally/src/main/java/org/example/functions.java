package org.example;

import java.sql.*;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class functions {
    // Set of allowed currency codes
    static Set<String> allowedCurrencies = Stream.of("USD", "JOD", "CAD", "EG").collect(Collectors.toSet());
    // Database connection details
    static final String JDBC_URL = "jdbc:mysql://localhost:3306/fx_deals";
    static final String USER = "root";
    static final String PASSWORD = "";

    // Validate if a Deal object is valid
    static boolean isValidDeal(Deal deal) {
        // Basic validation for demonstration purposes
        return deal.uniqueId != null && !deal.uniqueId.isEmpty() &&
                deal.fromCurrency != null && !deal.fromCurrency.isEmpty() &&
                deal.toCurrency != null && !deal.toCurrency.isEmpty() &&
                deal.timestamp > 0 && deal.amount > 0;
    }

    // Save a Deal to the database
    static void saveDealToDatabase(Deal deal) {
        // Check if the unique ID is unique
        if (!isUniqueIdUnique(deal.uniqueId)) {
            System.out.println("Error: Non-unique ID detected - " + deal.uniqueId);
            return;
        }

        // Save the deal to the database
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String sql = "INSERT INTO deals (uniqueId, fromCurrency, toCurrency, timestamp, amount) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, deal.uniqueId);
                preparedStatement.setString(2, deal.fromCurrency);
                preparedStatement.setString(3, deal.toCurrency);
                preparedStatement.setLong(4, deal.timestamp);
                preparedStatement.setDouble(5, deal.amount);
                preparedStatement.executeUpdate();
                System.out.println("Deal saved to the database: " + deal.uniqueId);
            }
        } catch (SQLException e) {
            // Handle SQL exception, print a user-friendly message, and log the exception
            System.out.println("Dear user, please note that an error has occurred... please try again");
            e.printStackTrace();
        }
    }

    // Check if a unique ID is unique in the database
    static boolean isUniqueIdUnique(String uniqueId) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String sql = "SELECT COUNT(*) FROM deals WHERE uniqueId = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, uniqueId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        return count == 0; // ID is unique if count is 0
                    }
                }
            }
        } catch (SQLException e) {
            // Handle SQL exception, print a user-friendly message, and log the exception
            System.out.println("Please make sure to enter a unique ID");
            e.printStackTrace();
        }
        return false; // Assume non-unique in case of an exception (handle appropriately in production)
    }

    // Create a Deal object from user input
    static Deal createDealFromUserInput() {
        Deal deal = new Deal();
        Scanner scanner = new Scanner(System.in);

        boolean uniqueIdValid = false;

        // Loop to ensure the entered unique ID is indeed unique
        while (!uniqueIdValid) {
            System.out.print("Enter unique ID: ");
            deal.uniqueId = scanner.nextLine();

            // Check if the entered ID is unique
            if (isUniqueIdUnique(deal.uniqueId)) {
                uniqueIdValid = true;
            } else {
                System.out.println("Error: Non-unique ID. Please enter another unique ID.");
            }
        }

        // Loop to ensure the entered fromCurrency is valid
        while (true) {
            System.out.print("Enter from currency (USD, JOD, CAD, EG): ");
            deal.fromCurrency = scanner.nextLine().toUpperCase(); // Convert to uppercase for case-insensitive comparison

            if (allowedCurrencies.contains(deal.fromCurrency)) {
                break;
            } else {
                System.out.println("Error: Invalid currency. Please enter a valid currency.");
            }
        }

        // Loop to ensure the entered toCurrency is valid
        while (true) {
            System.out.print("Enter to currency (USD, JOD, CAD, EG): ");
            deal.toCurrency = scanner.nextLine().toUpperCase(); // Convert to uppercase for case-insensitive comparison

            if (allowedCurrencies.contains(deal.toCurrency)) {
                break;
            } else {
                System.out.println("Error: Invalid currency. Please enter a valid currency.");
            }
        }

        // Set timestamp to the current time
        deal.timestamp = System.currentTimeMillis();

        // Get the amount from the user
        System.out.print("Enter amount: ");
        deal.amount = scanner.nextDouble();

        return deal;
    }
}
