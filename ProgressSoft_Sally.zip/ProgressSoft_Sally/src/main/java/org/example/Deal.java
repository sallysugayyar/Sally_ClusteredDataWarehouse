package org.example;

public class Deal {
    String uniqueId;
    String fromCurrency;
    String toCurrency;
    long timestamp;
    double amount;
}
